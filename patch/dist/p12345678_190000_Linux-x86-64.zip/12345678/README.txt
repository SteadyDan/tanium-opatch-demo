Patch 12345678  (SIMULATED - lab use only)
Database Release Update : 19.24.0.0.240716
Platform: Linux-x86-64

Apply:    cd 12345678 && opatch apply -silent
Rollback: opatch rollback -id 12345678 -silent
